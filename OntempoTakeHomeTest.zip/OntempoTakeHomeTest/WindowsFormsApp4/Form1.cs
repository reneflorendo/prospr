﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        string _ConnectionString;
        public Form1()
        {
            InitializeComponent();

            _ConnectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={Application.StartupPath}\Database1.mdf;Integrated Security=True";
            /* What you need to do:
			 * Design and develop a small application where the user enters the name of a geographical region 
			 *  into a text box, and clicks Load. (Assume the user will only enter these valid region names: Auckland and Hamilton.)
			 *  The names of all the retail branches belonging to that region will be displayed in a grid.
			 *  
			 * Design the UI with:
			 * A label with caption "Region"
			 * A entry field for identifying the region name (one of Auckland or Hamilton).
			 * A grid for displaying the names of branches in the region.
			 * A Load button.
			 * 
			 * Behaviour of the UI:
			 * The user identifies the region in the region entry field.
			 * The user clicks the Load button.			 
			 * The names of the branches in the selected region are displayed in a DataGrid control.
			 * 
			 * There is a Region class and a Branch class in this project. Both have a Name property.
			 * The Region class contains a List<Branch> objects, being the branches belonging to that region.
			 * Load the data from the database into those classes as needed to achieve the solution.
			 * Write appropriate WinForms code to get that data on screen.
			 *
			 * Email steve@ontempo.co.nz with questions!
			*/

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtRegion.Text.Length > 0)
                {
                    var branches = GetBranches(txtRegion.Text);

                    if (branches.Count > 0)
                    {

                        dgvBranches.DataSource = branches;
                        dgvBranches.Columns["Id"].Visible = false;
                    }
                    else
                    {
                        dgvBranches.DataSource=null;
                        MessageBox.Show("Please input valid Region!");
                    }
                }
                else
                {
                    MessageBox.Show("Region cannot be blank!");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("An error occurs for this transaction!");
            }
        }

        /// <summary>
        /// This method will get all branches by Region
        /// </summary>
        /// <param name="strRegion">filter by Region name</param>
        /// <returns></returns>
        private List<Branch> GetBranches(string strRegion)
        {

            List<Branch> branches = new List<Branch>();

            string queryString = "SELECT br.* FROM Branch br INNER JOIN Region reg ON br.RegionId=reg.Id WHERE reg.Name= @Name;";

            try
            {
                using (var connection = new SqlConnection(_ConnectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(queryString, connection))
                    {
                        command.Parameters.Add("@Name", SqlDbType.VarChar);
                        command.Parameters["@Name"].Value = txtRegion.Text;

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Call Read before accessing data. 
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Branch branch = new Branch
                                    {
                                        // Id = Convert.ToInt32(reader["Id"]), commented this since it only needs to display the names according to instructions
                                        Name = Convert.ToString(reader["Name"])
                                    };

                                    branches.Add(branch);
                                }

                            }

                            reader.Close();
                        }

                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return branches;
        }
    }
}
